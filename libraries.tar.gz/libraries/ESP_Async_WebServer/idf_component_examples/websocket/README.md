### Basic example to show how to use WebSockets
